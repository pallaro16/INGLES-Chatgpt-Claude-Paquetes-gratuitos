# INGLÉS | Paquete gratuito v0.4

**Actualización de v0.3**: añade preparación estructurada para Cambridge, Trinity y Oxford, niveles de aprendizaje A1–C1; añade tono por franja de edad. Mantiene el diagnóstico de 4 bloques, teoría antes de ejercicios y clases exclusivamente por chat.

## Instalación en un Proyecto de ChatGPT

**Solo debes usar cuatro elementos:**

1. Abre ChatGPT → Proyecto «INGLÉS» → menú del proyecto → **Instrucciones del proyecto**. Sustituye el contenido anterior por el texto completo de `00_COPIAR_INSTRUCCIONES.txt` (archivo para **copiar**, NO subir).
2. Elimina del apartado de fuentes las versiones antiguas de `01_MANUAL_TUTOR.txt` y `02_CURRICULO_LECCIONES.txt`. Conviene eliminarlas antes de añadir las nuevas para que no haya contradicciones.
3. Sube únicamente los tres archivos `.txt` dentro de `SUBIR_AL_PROYECTO/`, con sus nombres originales. **No subas el ZIP, el README ni las pruebas.**
4. Abre una conversación nueva para comprobar la versión v0.4; por ejemplo: «Soy adulto, quiero preparar Cambridge B2 First: hazme un plan y mi primera clase con teoría» o «Soy un padre que acompaña a un niño en A1 Movers».

## Compatible con Gratis

- ChatGPT Free: **hasta 5 archivos por proyecto** según documentación oficial consultada el 04-11-2026.
- Este paquete usa **3 fuentes** y deja **2 plazas libres**.
- Free tiene un límite general de **3 subidas al día**, sujeto a cambios. La actualización desde v0.3 implica tres cargas nuevas (dos reemplazos y un archivo añadido). Si el alumno ya ha subido otros archivos ese día, podrá completarla cuando se restablezca su cuota; no se recomienda insistir en reintentos fallidos.
- El texto del campo de instrucciones tiene **menos de 1.500 caracteres**, objetivo conservador de compatibilidad. **No afirmamos que 1.500 sea el límite de instrucciones de Proyectos**, pues no hay un máximo numérico oficial específico verificado.
- También funciona en planes de pago. No incluye servicios de pago ni herramientas de terceros.

## Selección de exámenes

| Nivel de aprendizaje | Cambridge | Trinity | Oxford Test of English |
|---|---|---|---|
| A1 | **A1 Movers** para niños; adultos: A1 general antes de A2 Key | **ISE A1**, también rutas GESE por grade | **Sin examen A1**; aprendizaje A1 para llegar a A2 |
| A2 | A2 Key / for Schools | ISE Foundation / GESE | Oxford Test of English / for Schools |
| B1 | B1 Preliminary / for Schools | ISE I / GESE | Oxford Test of English / for Schools |
| B2 | B2 First / for Schools | ISE II / GESE | Oxford Test of English o Advanced |
| C1 | C1 Advanced | ISE III / GESE | Oxford Test of English **Advanced** |

Son **rutas de preparación**, no titulaciones expedidas por este proyecto. Trinity GESE evalúa principalmente destrezas orales. Los exámenes y modalidades pueden sufrir cambios.

## Ajuste por edades y tono

- **Adulto 18+**: explica con claridad y usa sarcasmo leve cuando encaje, dirigido a rarezas del idioma o ejemplos ficticios. Nunca se ríe del estudiante ni de sus fallos.
- **Adolescente 13–17**: vocabulario cercano y motivador, sin infantilizar ni usar sarcasmo. Necesita consentimiento parental para utilizar ChatGPT.
- **Menor de 13**: solo se utiliza mediante un **adulto responsable que interactúa con ChatGPT**. El tutor simplifica, enseña con juegos verbales y no exige diagnóstico extenso.
- **Sin edad declarada**: tono neutro. Pregunta franja opcional, nunca datos íntimos. También permite «sin sarcasmo» en cualquier momento.

## Cómo estudiar sin gastar recursos de herramientas

Al empezar una clase, el tutor explica **teoría + 2–4 ejemplos traducidos + error típico + 3–5 ejercicios**. El usuario responde una sola tanda y recibe corrección. Los ejercicios, simulaciones, resúmenes y planes se escriben directamente en el chat, sin crear PDF, Word, fichas, audio ni imágenes. Agrupar ejercicios reduce los mensajes, pero **no elimina límites de uso**.

## Notas importantes

- El diagnóstico de la versión 0.3 se mantiene como filtro escrito inicial (4 bloques, aprox. 15–20 minutos). Un reto C1 es opcional si hay indicios o el alumno lo pide. No es un examen psicométricamente validado.
- No se pueden evaluar realmente **listening** ni pronunciación con solo una transcripción textual. La voz puede no estar disponible o tener límites. No se simula un cronómetro real.
- Las instrucciones del proyecto tienen prioridad como configuración, pero el modelo **no garantiza recuperar ni seguir literalmente cada sección** de todos los archivos en todas las sesiones. Prueba en un Proyecto real.
- No hay sincronización GitHub ↔ ChatGPT, base de datos, actualización automática de archivos, certificado de idiomas ni simulacro oficial de examen.
- Cada persona debe crear su **propio Proyecto privado**, no introducir datos de alumnos en uno público compartido.
- El material pedagógico y los ejercicios nuevos son originales y **no están afiliados ni avalados por Cambridge English, Trinity College London ni Oxford University Press/Universidad de Oxford**. Antes de publicar en GitHub, determina la licencia propia y añade atribuciones adecuadas. No se distribuyen sus pruebas originales.

## Enlaces de referencia

- Proyectos ChatGPT: https://help.openai.com/es-es/articles/10169521-projects-in-chatgpt
- Subidas de archivos: https://help.openai.com/es-es/articles/8555545-uploading-files-and-audio-to-chatgpt
- Uso con menores: https://help.openai.com/es-es/articles/8313401-is-chatgpt-safe-for-all-ages
- Cambridge: https://www.cambridgeenglish.org/es/exams-and-tests/qualifications/preparation/
- Trinity: https://trinitycollege.com/qualifications/english-language/ISE/ISE-paper/students
- Oxford: https://www.oup.es/oxfordtestofenglish/

**Estado**: prototipo v0.4 preparado para pruebas manuales en Proyecto real. La auditoría técnica del ZIP no sustituye una validación pedagógica ni el contraste con modelos y planes de ChatGPT.
