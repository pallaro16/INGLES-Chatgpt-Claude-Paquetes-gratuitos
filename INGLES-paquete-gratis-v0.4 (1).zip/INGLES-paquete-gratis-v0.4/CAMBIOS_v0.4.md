# CAMBIOS | v0.3 → v0.4

- **Conservado**: prueba inicial de cuatro bloques, diagnóstico prudente, banco de 16 unidades previo, teoría + ejercicios por chat, resúmenes y restricciones de creación de archivos.
- **Añadido**: preparación por certificadora y nivel A1–C1, distinguiendo exámenes que realmente existen; manual adicional de referencia con teoría, microtareas originales, técnicas y rúbricas.
- **Añadido**: 10 unidades avanzadas F16–F25 y dos retos voluntarios C1.
- **Añadido**: estilo por edad: sarcasmo leve y opcional para adultos; neutral para adolescentes; lúdico con intervención de adulto para menores de 13 años.
- **Corregido**: no confundir Cambridge A1 Movers con certificación general de adultos, Trinity ISE A1 con ISE Foundation y Oxford A1 con certificado inexistente.
- **Compatibilidad**: 3 fuentes (de 5 Free), instrucciones pegables breves, 2 plazas para archivos propios; instalación desde cero con 3 subidas.
- **Pendiente**: validar comportamiento real en cuenta Free, revisión docente, licencia y atribuciones antes de publicación estable en GitHub.
